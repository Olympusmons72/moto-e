# Use this to add P1m to CM's lunch command menu
for var in eng user userdebug; do
  add_lunch_combo lineage_e4-$var
done
