int get_capture_position(void)
{
    return 0;
}
