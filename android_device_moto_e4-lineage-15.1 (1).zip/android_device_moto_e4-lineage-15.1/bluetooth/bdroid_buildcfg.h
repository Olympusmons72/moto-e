#ifndef _BDROID_BUILDCFG_H
#define _BDROID_BUILDCFG_H

#define BTM_DEF_LOCAL_NAME   "Moto E4"
// test
//#define KERNEL_MISSING_CLOCK_BOOTTIME_ALARM TRUE
#define BTA_DISABLE_DELAY 1000 /* in milliseconds */
#define BLE_VND_INCLUDED   TRUE
#endif