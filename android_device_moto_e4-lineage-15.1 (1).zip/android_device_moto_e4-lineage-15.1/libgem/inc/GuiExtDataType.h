#pragma GCC system_header
#ifndef __GUIEXT_DATAEYPE_H__
#define __GUIEXT_DATAEYPE_H__

enum {
    GUI_EXT_USAGE_GPU = 0,
    GUI_EXT_USAGE_HWC = 1,
    GUI_EXT_USAGE_MAX
};

#endif




